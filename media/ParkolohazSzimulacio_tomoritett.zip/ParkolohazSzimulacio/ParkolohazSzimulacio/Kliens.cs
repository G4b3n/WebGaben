﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace ParkolohazSzimulacio
{
    internal class Kliens
    {
        Random vszg=new Random(); //random függvény hívás
        String[] rendszamok = //megadjuk a renmdszámokat
        {
            "KJH482 ",
            "MGT915 ",
            "BRP208 ",
            "ZQX533 ",
            "VWL726 ",
            "NXP104 ",
            "DHS859 ",
            "FLK312 ",
            "XJY674 ",
            "TCW940 ",
            "SGR255 ",
            "HKM118 ",
            "LPV403 ",
            "JNZ592 ",
            "BRD831 ",
            "MFX067 ",
            "KWT324 ",
            "PLK986 ",
            "RVB145 ",
            "SCZ702 ",
            "TND558 ",
            "UWX219 ",
            "VKB487 ",
            "WCH031 ",
            "XFM662 ",
            "YRS914 ",
            "ZTL105 ",
            "ADN473 ",
            "BKP820 ",
            "CFR339 ",
            "DGT614 ",
            "EHK297 ",
            "FML581 ",
            "GSN046 ",
            "HJB725 ",
            "JKV412 ",
            "LPR803 ",
            "MNW556 ",
            "NBF289 ",
            "PQC107 ",
            "RFV648 ",
            "SGT932 ",
            "THK441 ",
            "UJM275 ",
            "VXN810 ",
            "WLP394 ",
            "ZCR516 ",
            "KLT229 ",
            "HFD711 ",
            "BVC008 ",
            "AAAB123",
            "ACDF582",
            "BAMH910",
            "BBRN344",
            "CCPT607",
            "CDXW215",
            "DAHS839",
            "DEJK102",
            "EAVB476",
            "EBLP391",
            "FAST558",
            "FBXC724",
            "GNGT119",
            "GPHR830",
            "HAMK642",
            "HSBN205",
            "IDJK493",
            "IFPL917",
            "JVHW056",
            "KBRT338"
        };
        public Kliens() 
        { 
            TcpClient kliens = new TcpClient(); //adatküldéshez csatlakozik
            kliens.Connect(IPAddress.Parse("127.0.0.1"), 2025); //erre az IP-re küldi
            NetworkStream csatorna=kliens.GetStream();  //a csatornán keresztül
            StreamWriter request=new StreamWriter(csatorna);    //elküldjük a rendszámot
            request.Write(rendszamok[vszg.Next(0,rendszamok.Length-1)]);    
            request.Close();
        }
    }
}
